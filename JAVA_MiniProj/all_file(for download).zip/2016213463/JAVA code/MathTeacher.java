/**
 * This class is class CreatGUI's instantiation.
 * @since 9.0
 * @author Haoyan Gong
 * @version 1.0
 * 
 */
public class MathTeacher{
	/**
	 * This method is main method.
	 * @param args A string brought from the command line.
	 * 
	 */
	public static void main(String[] args) {
		new CreatGUI();
	}
}
